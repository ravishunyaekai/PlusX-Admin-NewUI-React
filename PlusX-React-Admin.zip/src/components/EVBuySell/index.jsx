import React from "react";
import { Outlet } from "react-router-dom";

const EvBuySell = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};

export default EvBuySell;