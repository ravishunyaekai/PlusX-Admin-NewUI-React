import React from "react";
import { Outlet } from "react-router-dom";

const Offer = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};

export default Offer;