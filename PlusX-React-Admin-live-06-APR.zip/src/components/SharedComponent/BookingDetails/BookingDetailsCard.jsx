import React from 'react'
import styles from './bookingdetails.module.css'

const BookingDetailsCard = () => {
  return (
    <div>BookingDetailsCard</div>
  )
}

export default BookingDetailsCard