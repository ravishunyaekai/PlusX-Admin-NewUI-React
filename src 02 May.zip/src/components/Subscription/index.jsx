import React from "react";
import { Outlet } from "react-router-dom";

const Subscription = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};

export default Subscription;